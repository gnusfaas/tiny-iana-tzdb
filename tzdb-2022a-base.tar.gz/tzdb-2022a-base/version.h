static char const PKGVERSION[]="(tzcode) ";
static char const TZVERSION[]="2022a";
static char const REPORT_BUGS_TO[]="tz@iana.org";
